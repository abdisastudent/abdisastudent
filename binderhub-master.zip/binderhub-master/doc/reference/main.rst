main
====


Module: :mod:`binderhub.main`
-----------------------------

.. automodule:: binderhub.main

.. currentmodule:: binderhub.main

:class:`MainHandler`
--------------------

.. autoclass:: MainHandler
    :members:

:class:`ParameterizedMainHandler`
---------------------------------

.. autoclass:: ParameterizedMainHandler
    :members:

:class:`LegacyRedirectHandler`
------------------------------

.. autoclass:: LegacyRedirectHandler
    :members:
