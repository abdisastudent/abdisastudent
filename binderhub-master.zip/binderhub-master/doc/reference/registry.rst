registry
========

binderhub.repoproviders


Module: :mod:`binderhub.registry`
---------------------------------

.. automodule:: binderhub.registry

.. currentmodule:: binderhub.registry


:class:`DockerRegistry`
-----------------------

.. autoclass:: DockerRegistry
    :members:
