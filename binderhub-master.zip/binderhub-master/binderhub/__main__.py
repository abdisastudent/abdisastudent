if __name__ == '__main__':
    from binderhub.app import main
    main()
