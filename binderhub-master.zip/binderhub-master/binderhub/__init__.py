# next three lines were added by versioneer
from . import _version
__version__ = _version.get_versions()['version']
